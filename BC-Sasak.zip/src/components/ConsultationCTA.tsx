// File sementara untuk mengatasi error Tailwind CSS
// File ini akan dihapus setelah cache dibersihkan

const ConsultationCTA = () => {
  return null;
};

export default ConsultationCTA;
